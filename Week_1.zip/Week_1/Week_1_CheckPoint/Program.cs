﻿Console.WriteLine("=====\tSTUDENT REPORT\t=====");
Console.WriteLine("Student: \tAlex");
Console.WriteLine("Age: \t24");
Console.WriteLine("Course: \tC# Fundamentals");